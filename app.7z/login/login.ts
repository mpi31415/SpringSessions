export class loginStat{
    login: boolean;
    sessionId: string;
    sessionTimeout: Date;
}
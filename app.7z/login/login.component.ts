import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { from } from 'rxjs';
import { LoginService } from '../service/login.service';
import {User} from '../user'

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  user: User;
  constructor(private router: Router, private loginService: LoginService) {
    this.user = new User();
   }

  ngOnInit(): void {
  }
  onSubmit(){
    this.loginService.login(this.user);
  }

}

import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { CookieService } from 'ngx-cookie-service';
import { AppService } from '../app.service';
import { loginStat } from '../login/login';
import { User } from '../user';

@Injectable({
  providedIn: 'root'
})
export class LoginService {

  loginStatus: loginStat;

  constructor(private http: HttpClient, private router: Router, private app: AppService, private cookieService: CookieService) {

   }


  login(user: User){
    return this.http.post<loginStat>('http://localhost:8080/users/login', user).subscribe(data => {
      this.loginStatus = data;
      const dateNow = new Date();
     
      if(data.login==true){
        sessionStorage.removeItem('login');
        sessionStorage.setItem('login', 'true');
        dateNow.setHours(dateNow.getHours() + 1);
        this.cookieService.set('sessionId', this.loginStatus.sessionId, dateNow);
        console.log(this.cookieService.get('sessionId'));
        this.app.authenticated= true;
        this.router.navigate(['/']);
      }else{
        sessionStorage.removeItem('login');
        this.app.authenticated= false;
      }

    });
  }
  logout(){
    this.http.post<loginStat>('http://localhost:8080/users/logout', this.cookieService.get('sessionId')).subscribe(data=>{
      console.log(data.login);
    });
    this.app.authenticated= false;
    this.cookieService.delete('sessionId');
    sessionStorage.removeItem('login');
    this.router.navigate(['/']);
  }
}

import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CookieService } from 'ngx-cookie-service';
import { LoginService } from '../service/login.service';

@Component({
  selector: 'app-logout',
  templateUrl: './logout.component.html',
  styleUrls: ['./logout.component.css']
})
export class LogoutComponent implements OnInit {

  constructor(private router: Router, private logout: LoginService, private cookie: CookieService) { }

  ngOnInit(): void {
    this.logout.logout();
    this.cookie.deleteAll();
    this.router.navigate(['/login']);
  }

}

import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable()
export class AppService {

  authenticated = false;
  
  constructor(private httpClient: HttpClient) {
    if(sessionStorage.getItem('login')=='true'){
      this.authenticated = true;
    }else{
      if(sessionStorage.getItem('login')!=null){
        sessionStorage.removeItem('login');
      }
      this.authenticated = false;
    }
   }

  
  
  

}

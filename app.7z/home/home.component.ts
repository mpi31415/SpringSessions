import { HttpClient, HttpParams } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { CookieService } from 'ngx-cookie-service';
import { Session } from 'protractor';
import { AppComponent } from '../app.component';
import { AppService } from '../app.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit{
  locAuth = this.app.authenticated;
  try = {}
 
  constructor(private httpClient: HttpClient, private app: AppService,private cookieService: CookieService) { }

  ngOnInit(): void {
    const params = new HttpParams();
    params.set('sessionId', this.cookieService.get('sessionId'))

    console.log(this.locAuth);
    this.httpClient.get('http://localhost:8080/resource',{params:params}).subscribe(data=>{
      this.try =data;
    })
  }

}
